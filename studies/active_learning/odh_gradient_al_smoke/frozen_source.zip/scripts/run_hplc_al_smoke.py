"""Run the gated ODH development study in the project conda environment."""
import argparse
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
os.environ.setdefault('MPLCONFIGDIR', '/tmp/hplc_al_matplotlib')

from hplc_al.runner import prepare, tests_gate, duration_audit, freeze_protocol, run_trajectories

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'test', 'audit', 'freeze', 'run', 'report'])
    args = parser.parse_args()
    if args.action == 'report':
        from hplc_al.reporting import report
        report()
    else:
        {'prepare':prepare, 'test':tests_gate, 'audit':duration_audit,
         'freeze':freeze_protocol, 'run':run_trajectories}[args.action]()
